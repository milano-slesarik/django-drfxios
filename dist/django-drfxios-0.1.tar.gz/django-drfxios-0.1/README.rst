=======
DrfXios
=======

**DrfXios** simplifies communication between frontend and Django Rest Framework API.

Quick start
-----------

pip install django-drfxios