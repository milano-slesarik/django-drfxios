String.prototype.capitalize = function () {
    return this.charAt(0).toUpperCase() + this.slice(1)
}

axios.defaults.xsrfCookieName = 'csrftoken';
axios.defaults.xsrfHeaderName = "X-CSRFTOKEN";

function camelCaseize(text) {
    var parts = text.split('_')
    var final = ''
    for (var part of parts) {
        final += part.capitalize();
    }

    return final
}

class Drfxios {
    static ID_PLACEHOLDER = 'thisWillBeReplacedByActualID'
    constructor(urls) {
        this.urls = urls;
        var self = this;
        for (var model of Object.keys(urls)) {

            var modelCapitalized = camelCaseize(model);
            let detail_url = urls[model]['detail']
            let list_url = urls[model]['list']
            // add list, detail, delete, update, create
            // getModelList
            Drfxios.prototype['get' + modelCapitalized + 'List'] = (filter) => {
                var params = new URLSearchParams();
                if (filter) {
                    for (let [key, value] of Object.entries(filter)) {
                        if (Array.isArray(value)) {
                            for (let i of value) {
                                if (value!==null){
                                params.append(key, i);
                                }
                            }
                        } else {
                            if (value!==null) {
                                params.append(key, value);
                            }
                        }
                    }
                }

                var request = {
                    params: params
                };
                return axios.get(list_url, request)
            };
            // getModelDetail
            Drfxios.prototype['get' + modelCapitalized] = function (id) {
                var detail_url_final = detail_url.replace(Drfxios.ID_PLACEHOLDER, id)
                return axios.get(detail_url_final)
            };
            // deleteModel
            Drfxios.prototype['delete' + modelCapitalized] = id => {
                var detail_url_final = detail_url.replace(Drfxios.ID_PLACEHOLDER, id)
                return axios.delete(detail_url_final)
            };
            // createModel
            Drfxios.prototype['create' + modelCapitalized] = jsn => {
                return axios.post(list_url, jsn)
            };
            // updateModel
            Drfxios.prototype['update' + modelCapitalized] = (jsn, id = null) => { // todo put
                var detail_url_final = detail_url.replace(Drfxios.ID_PLACEHOLDER, id !== null ? id : jsn.id)
                return axios.patch(detail_url_final, jsn)
            };
            Drfxios.prototype['patch' + modelCapitalized] = (jsn, id = null) => {
                var detail_url_final = detail_url.replace(Drfxios.ID_PLACEHOLDER, id !== null ? id : jsn.id)
                return axios.patch(detail_url_final, jsn)
            };
        }
    }

    getApiUrl(model, urltype, id = null, params = {}) {
        var url = this.urls[model][urltype];

        if (id) {
            url = url.replace(Drfxios.ID_PLACEHOLDER, id)
        }
        for (var key of Object.keys(params)) {
            url = updateQueryString(key, params[key], url)
        }
        return url
    }

    static fromModels(base_url, models) {
        var urls = {}
        for (let model of models) {
            let url = '/' + base_url + '/' + model + '/';
            urls[model] = {
                list: url,
                detail: url + Drfxios.ID_PLACEHOLDER + '/'
            }
        }
        return new this(urls)
    }
}

function updateQueryString(key, value, url) {
    var re = new RegExp("([?&])" + key + "=.*?(&|#|$)(.*)", "gi"),
        hash;

    if (re.test(url)) {
        if (typeof value !== 'undefined' && value !== null) {
            return url.replace(re, '$1' + key + "=" + value + '$2$3');
        } else {
            hash = url.split('#');
            url = hash[0].replace(re, '$1$3').replace(/(&|\?)$/, '');
            if (typeof hash[1] !== 'undefined' && hash[1] !== null) {
                url += '#' + hash[1];
            }
            return url;
        }
    } else {
        if (typeof value !== 'undefined' && value !== null) {
            var separator = url.indexOf('?') !== -1 ? '&' : '?';
            hash = url.split('#');
            url = hash[0] + separator + key + '=' + value;
            if (typeof hash[1] !== 'undefined' && hash[1] !== null) {
                url += '#' + hash[1];
            }
            return url;
        } else {
            return url;
        }
    }
}