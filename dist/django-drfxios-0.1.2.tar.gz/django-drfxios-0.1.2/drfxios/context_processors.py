import json


def drfwrapper_resolver(request):
    from api.urls import router
    r = router.registry
    models_list = [x[0] for x in r]
    return {
        'DRFXIOS':{
            'MODELS_LIST':json.dumps(models_list)
        }
    }