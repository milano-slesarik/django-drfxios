from django.apps import AppConfig


class DrfxiosConfig(AppConfig):
    name = 'drfxios'
