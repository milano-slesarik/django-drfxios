from django.apps import AppConfig


class DrfXiosConfig(AppConfig):
    name = 'drfxios'
